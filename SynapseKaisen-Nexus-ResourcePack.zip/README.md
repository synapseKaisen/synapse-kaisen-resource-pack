# Synapse Kaisen — Resource Pack do Nexus

Este pack dá uma identidade visual própria a cada Nexus, exibido pelo plugin
como item-modelo próprio de ametista. Ele não substitui a textura de nenhum
bloco comum do Minecraft.

| Nexus | Modelo | Visual |
| --- | ---: | --- |
| Núcleo Soberano | `9001` | violeta e ciano |
| Econômico | `9002` | esmeralda e ouro |
| Militar | `9003` | carmesim e brasa |
| Proteção | `9004` | safira e prata |

Para testar localmente, compacte o conteúdo desta pasta em `.zip` e coloque o
arquivo na pasta `resourcepacks` do cliente Minecraft. Ative-o antes de entrar
no servidor.

Para distribuição automática pelo plugin, hospede esse `.zip` por uma URL
**HTTPS pública e direta** (a URL precisa baixar o arquivo, não abrir uma tela
do GitHub). Calcule o SHA-1 do ZIP e preencha, em
`plugins/SynapseKaisen/config.yml`:

```yml
resource-pack:
  url: "https://assets.seudominio.com/SynapseKaisen-Nexus-ResourcePack.zip"
  sha1: "sha1-do-zip-com-40-caracteres"
```

Com ambos os campos válidos, o cliente recebe ao entrar a pergunta nativa para
baixar o pack. Ele é opcional (`force: false`), então quem recusar continua no
servidor com os modelos de ametista padrão.
